package com.example.hendrik.mianamalaga;

public interface OnUpdateResponseInFragment {
    void updateResponses(String response);
}
